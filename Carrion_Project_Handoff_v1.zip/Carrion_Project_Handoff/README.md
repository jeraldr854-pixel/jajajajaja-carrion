# Carrion-inspired Terraria Mod — Project Handoff

This archive is the portable project notebook. Re-upload the ZIP in a future chat to continue from the recorded state.

## Important
- This is a **handoff archive**, not the original Carrion APK/ZIP and not a working mod build.
- The original uploaded archive was named `Carrion-v1.0.44-unlocked-apkvision.zip`. Its contents are **not included** here.
- Do not treat unverified historical notes as confirmed source-code findings.
- Update `PROJECT_STATE.md` and `research/RESEARCH_LOG.md` whenever progress is made.

## Suggested workflow
1. Upload this ZIP at the start of a new project chat.
2. Upload the original game archive or relevant extracted files when source inspection is needed.
3. Ask to update this handoff archive after meaningful work.
4. Keep dated backups of each milestone.

## Folder guide
- `PROJECT_STATE.md` — current goals, constraints, and status.
- `research/RESEARCH_LOG.md` — findings and investigation history.
- `research/FILE_INDEX.csv` — index of files inspected from the original archive.
- `research/NEXT_STEPS.md` — immediate tasks.
- `src/` — our own mod source code (currently empty).
- `assets/` — project-owned assets (currently empty).
