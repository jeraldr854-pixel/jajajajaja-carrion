# Project-owned assets

Place original assets we create or are licensed to use here.
