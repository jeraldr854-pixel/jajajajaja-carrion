# Project State

Last packaged: 2026-11-21

## Working title
**Carrion: Outside the Lab** — proposed working title only; user has not confirmed it as the official name.

## Project concept
Create an original Terraria/tModLoader mod inspired by the creature behavior and feel of *Carrion*. The goal is to build our own implementation rather than copy proprietary game code or assets.

## Main design goals
1. Detect nearby Terraria terrain (walls, floors, ceilings, and corners).
2. Make the creature's body adapt to surrounding terrain.
3. Build a flexible, spaghetti-like body using connected nodes/segments.
4. Create fluid movement and tentacle-like motion.
5. Add biomass systems and evolutions after the movement foundation works.
6. Support switching between the normal Terraria character and the creature form (previously discussed as “Transformation model B”).

## Previously discussed environment
These values came from prior project discussion and should be verified before building:
- Terraria: 1.4.4.9
- tModLoader: 2026.9.7.3.1
- Target device mentioned: Infinix Hot 40i

## Original reference archive
- Filename previously uploaded: `Carrion-v1.0.44-unlocked-apkvision.zip`
- It is not included in this handoff ZIP.
- Earlier conversation mentioned an archive with roughly 750 entries and references to `MonsterNode`, `MonsterNodeList`, tentacle/monster data, node interpolation, collision-related hooks, morph masks, and `BuildBowels`.
- **Verification status: unverified historical notes.** Re-open the original archive and confirm exact paths, code, and behavior before relying on these details.

## Current implementation status
- No verified mod source code is included in this handoff.
- Terrain detection: planned, not verified as implemented.
- Node-based body: planned, not verified as implemented.
- Biomass/evolutions: design discussion only; implementation status unknown.
- APK investigation: previously started, but source files are not available in this archive.

## Technical principles
- Write our own code and use the reference archive for learning and behavioral analysis.
- Keep a clear distinction between observed reference behavior and our implementation.
- Record exact file paths, class names, methods, and evidence for every source finding.
- Test features incrementally in tModLoader; do not assume code works until compiled and tested.
