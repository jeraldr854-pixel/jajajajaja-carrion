# Research Log

Use one dated section per investigation. Include exact archive path(s), class/method names, what was observed, and confidence.

## 2026-11-21 — Handoff reconstructed from prior conversation context

### Historical notes (not yet re-verified)
Earlier conversation summaries mention:
- Approx. 750 archive entries.
- Names/systems: `MonsterNode`, `MonsterNodeList`.
- Tentacle and monster data.
- Node interpolation and collision-related hooks.
- Morph masks and `BuildBowels`.

These are leads only. The original files are not present in this handoff archive, so exact paths, signatures, and behavior remain unknown.

### Confirmed in current handoff
- Original archive filename remembered from the conversation: `Carrion-v1.0.44-unlocked-apkvision.zip`.
- Project goal: an original Carrion-inspired Terraria/tModLoader creature with terrain-adaptive, node-based movement.

## Investigation entry template

### YYYY-MM-DD — Short title
- Archive/file path:
- Class/type:
- Method/member:
- What the source actually does:
- How it may inform our implementation:
- Evidence (small code excerpt or line range):
- Confidence: confirmed / likely / unverified
- Follow-up:
