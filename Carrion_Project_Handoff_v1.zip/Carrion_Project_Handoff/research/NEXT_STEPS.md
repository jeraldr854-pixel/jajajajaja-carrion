# Next Steps

## Priority 1 — Restore source access
- [ ] Re-upload `Carrion-v1.0.44-unlocked-apkvision.zip` or the extracted source files.
- [ ] List archive contents and preserve the exact folder structure.
- [ ] Identify the actual files corresponding to `MonsterNode` / `MonsterNodeList` (if those names are present).
- [ ] Record exact paths and inspect the node update, interpolation, and collision logic.
- [ ] Separate confirmed findings from guesses.

## Priority 2 — Build our own movement foundation
- [ ] Confirm the installed Terraria and tModLoader versions.
- [ ] Create/verify a minimal compiling mod project.
- [ ] Design a node-chain data structure for the creature body.
- [ ] Prototype terrain sampling for nearby solid tiles.
- [ ] Prototype body placement and smoothing around corners.
- [ ] Test performance and collision behavior in-game.

## Priority 3 — Expand gameplay
- [ ] Add movement modes and tentacle behavior.
- [ ] Add biomass mechanics.
- [ ] Add evolutions with clear gameplay unlock conditions.
- [ ] Implement transformation between player form and creature form.

## Working rule
Do not jump to biomass/evolutions until terrain adaptation and core body movement are stable.
